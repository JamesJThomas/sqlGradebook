delimiter $
create procedure display_error(message varchar(255))
begin
signal sqlstate "45000" set message_text = message;
end$
