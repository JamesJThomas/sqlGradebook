create procedure delete_enrollment(enr_id int)
begin
if not exists(select * from enrollment where enrollment_id = enr_id) then
call display_error(concat("enrollment ",enr_id," doesn't exist. For a full listing of enrollments, select enrollment->list"));
else
delete from enrollment where enrollment_id = enr_id;
end if;
end$
