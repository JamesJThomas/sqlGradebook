create procedure insert_assignment(description varchar(255), cat_id int, points_possible int)
begin
if not exists(select * from category where category_id = cat_id) then
call display_error(concat("category ",cat_id," doesn't exist"));
elseif points_possible <= 0 then
call display_error("points possible should be a positive integer");
else
insert into assignment(assignment_description, category_id, assignment_points_possible) values(description, cat_id, points_possible);
end if;
end$
