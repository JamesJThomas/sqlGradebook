create procedure list_student()
begin
select * from student;
end$
