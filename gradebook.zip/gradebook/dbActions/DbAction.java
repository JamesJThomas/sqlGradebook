package dbActions;
/**
Interface for all db actions
*/
public interface DbAction
{
/**
Method that performs a given category of action. For example, in the StudentAction class, this method will let the user select and perform actions related to students
*/
void perform() throws ProgramDoneException;
}
