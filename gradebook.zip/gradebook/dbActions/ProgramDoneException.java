package dbActions;
/**
This exception is thrown when the program is supposed to terminate
*/
public class ProgramDoneException extends Exception
{
public ProgramDoneException(String message)
{
super(message);
}
}
