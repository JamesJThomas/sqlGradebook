package dbActions;
public class QuitAction implements DbAction
{
public void perform() throws ProgramDoneException
{
throw new ProgramDoneException("");
}
}

