//This package contains a class that performs grade calculations.
package dbActions.gradeActions;
import dbActions.*;
import dbActions.tableActions.*;
import java.sql.*;
public class GradeAction implements DbAction
{
private Connection connection;
public GradeAction(Connection c)
{
connection = c;
}
public void perform()
{
int gradeType = Utils.readInt("Please select from the following options:\n1: calculate final grade(fills in 0 for missing assignments)\n2: calculate current grade(only includes assignments up to this point)");
switch(gradeType)
{
case 1:
case 2:
try
{
int student = Utils.readInt("enter the id number of the student for whom you wish to calculate a grade:");
int course = Utils.readInt("enter the id number of the course to which this grade applies:");
PreparedStatement ps = connection.prepareStatement("select calculate_grade(?,?,?)");
ps.setInt(1,student);
ps.setInt(2,course);
ps.setInt(3,gradeType-1);
ResultSet rs = ps.executeQuery();
rs.next();
double grade = rs.getDouble(1);
System.out.println("student "+student+"has a grade of "+(grade*100)+"percent");
}
catch(SQLException s)
{
System.out.println(s.getMessage());
}
break;
default:
System.out.println("grade type must be 1 or 2");
break;
}
}
}
