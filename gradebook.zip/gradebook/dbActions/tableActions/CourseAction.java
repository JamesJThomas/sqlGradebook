package dbActions.tableActions;
import java.sql.*;
public class CourseAction extends TableAction
{
public CourseAction(Connection c)
{
super(c);
entity = "course";
insert = new Parameter[6];
insert[0] = new Parameter("enter course subject(for example, cs)",Type.STRING,"course_subject");
insert[3] = new Parameter("enter course description(for example, principles of database systems)",Type.STRING,"course_description");
insert[1] = new Parameter("enter course level(for example, 3810)", Type.INT,"course_level");
insert[2] = new Parameter("enter course section(for example, 002)", Type.INT,"course_section");
insert[4] = new Parameter("enter course term(for example, 1 for fall, 2 for spring, or 3 for summer)", Type.INT,"course_term");
insert[5] = new Parameter("enter course year(for example, 1999)", Type.INT,"course_year");
}
}
