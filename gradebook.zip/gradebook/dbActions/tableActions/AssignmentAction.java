package dbActions.tableActions;
import java.sql.*;
public class AssignmentAction extends TableAction
{
public AssignmentAction(Connection c)
{
super(c);
entity = "assignment";
insert = new Parameter[3];
insert[0] = new Parameter("enter assignment description(for example, exam 1)",Type.STRING,"assignment_description");
insert[1] = new Parameter("enter the id number of the category to which this assignment applies",Type.INT,"category_id");
insert[2] = new Parameter("enter the number of points possible for this assignment",Type.INT,"assignment_points_possible");
}
}
