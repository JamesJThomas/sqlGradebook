package dbActions.tableActions;
import java.sql.*;
//This class is used to print out the contents of a result set as a comma-separated list of values.
public class ResultSetViewer
{
ResultSet rs;
public ResultSetViewer(ResultSet rs)
{
this.rs = rs;
}
//Gets the value of a column in the current row as a string returns "#error"; if there is an exception..
public String getColumn(int index)
{
try
{
Object value = rs.getObject(index);
if(value != null)
{
return value.toString();
}
else
{
return "n/a";
}
}
catch(SQLException s)
{
return "#error";
}
}
//Gets the string representation of a row. Each row will be on a separate line in the final result and columns will be separated by commas. returns "#error"; if there is an exception.
public String getRow()
{
try
{
int count = rs.getMetaData().getColumnCount();
String row = getColumn(1);
int i;
for(i = 2; i <= count; i++)
{
row += ","+getColumn(i);
}
row += "\n";
return row;
}
catch(SQLException s)
{
return "#error";
}
}
//Method to get the column headers. The header of the final result is a comma-separated list of column names terminated with a newline. returns "#error"; if there is an exception.
public String getHeader()
{
try
{
ResultSetMetaData rsmd = rs.getMetaData();
int count = rsmd.getColumnCount();
String header = rsmd.getColumnName(1);
int i;
for(i = 2; i <= count; i++)
{
header += ","+rsmd.getColumnName(i);
}
header += "\n";
return header;
}
catch(SQLException s)
{
return "#error";
}
}
//This toString method is used for printing out the result set.
public String toString()
{
try
{
String head = getHeader();
String body = "";
while(rs.next())
{
body += getRow();
}
return head+body;
}
catch(SQLException s)
{
return "#error";
}
}
}
