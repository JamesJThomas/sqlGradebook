package dbActions.tableActions;
import java.sql.*;
public class StudentAction extends TableAction
{
public StudentAction(Connection c)
{
super(c);
entity = "student";
insert = new Parameter[5];
insert[0] = new Parameter("enter student id(for example, 900682683)",Type.INT,"student_id");
insert[1] = new Parameter("enter first name(for example, James)",Type.STRING,"student_first_name");
insert[2] = new Parameter("enter middle initial(for example, J; enter the empty string if there is no middle initial)",Type.STRING,"student_middle_initial");
insert[3] = new Parameter("enter last name(for example, Thomas)",Type.STRING,"student_last_name");
insert[4] = new Parameter("enter suffix(for example, Jr, or enter the empty string if there is no suffix)",Type.STRING,"student_suffix");
}
}
