package dbActions.tableActions;
import java.sql.*;
public class CategoryAction extends TableAction
{
public CategoryAction(Connection c)
{
super(c);
entity = "category";
insert = new Parameter[3];
insert[0] = new Parameter("enter category description(for example, homework)",Type.STRING,"category_description");
insert[1] = new Parameter("enter the id number of the course to which this category applies",Type.INT,"course_id");
insert[2] = new Parameter("enter category weight(for example, enter 50 if the category is worth 50 percent of the grade)",Type.DOUBLE,"category_weight");
}
}
