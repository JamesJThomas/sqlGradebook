//This class is meant to define a new type for query parameters
package dbActions.tableActions;
public class Parameter
{
private String description;
private Type type;
private String affectedColumn;
public Parameter(String d, Type t,String a)
{
description = d;
type  = t;
affectedColumn = a;
}
public String getDescription()
{
return description;
}
public Type getType()
{
return type;
}
public String getAffectedColumn()
{
return affectedColumn;
}
}
