package dbActions.tableActions;
public enum Type
{
INT, STRING, DOUBLE
}
