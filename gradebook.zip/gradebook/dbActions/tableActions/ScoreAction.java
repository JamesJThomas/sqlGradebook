package dbActions.tableActions;
import java.sql.*;
public class ScoreAction extends TableAction
{
public ScoreAction(Connection c)
{
super(c);
entity = "score";
insert =new Parameter[3];
insert[0] = new Parameter("enter the id number of the enrollment to which this score applies", Type.INT,"enrollment_id");
insert[1] = new Parameter("enter the id number of the assignment to which this score applies", Type.INT,"assignment_id");
insert[2] = new Parameter("enter the number of points earned on this assignment",Type.INT,"score_points_earned");
}
}
