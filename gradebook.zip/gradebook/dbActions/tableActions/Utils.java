//This is a class of utility functions to make writing the actual query functions easier.
package dbActions.tableActions;
import java.util.Scanner;
import java.sql.*;
public class Utils
{
//Reads an integer without crashing.
public static int readInt(String prompt)
{
boolean done = false;
Scanner keyboard = new Scanner(System.in);
int x = 0;
while(!done)
{
try
{
System.out.println(prompt);
x = keyboard.nextInt();
done = true;
}
catch(Exception e)
{
System.out.println("invalid input. please try again");
keyboard.nextLine();
}
}
return x;
}
//Reads a double without crashing.
public static double readDouble(String prompt)
{
boolean done = false;
Scanner keyboard = new Scanner(System.in);
double x = 0;
while(!done)
{
try
{
System.out.println(prompt);
x = keyboard.nextDouble();
done = true;
}
catch(Exception e)
{
System.out.println("invalid input. please try again");
keyboard.nextLine();
}
}
return x;
}
//Reads a string without crashing
public static String readString(String prompt)
{
boolean done = false;
Scanner keyboard = new Scanner(System.in);
String x = "";
while(!done)
{
try
{
System.out.println(prompt);
x = keyboard.nextLine();
done = true;
}
catch(Exception e)
{
System.out.println("invalid input. please try again");
}
}
return x;
}
//sets an int query parameter
public static void setInt(CallableStatement cs, int num, int val)
{
try
{
cs.setInt(num,val);
}
catch(SQLException s)
{
System.out.println(s.getMessage());
}
}
//sets a double query parameter
public static void setDouble(CallableStatement cs, int num, double val)
{
try
{
cs.setDouble(num,val);
}
catch(SQLException s)
{
System.out.println(s.getMessage());
}
}
//sets a string query parameter
public static void setString(CallableStatement cs, int num, String val)
{
try
{
cs.setString(num,val);
}
catch(SQLException s)
{
System.out.println(s.getMessage());
}
}
//Gets the query parameter list that is suitable for CallableStatement.prepareCall
public static String getParameterList(int len)
{
String list = "?";
int i;
for(i = 1; i < len; i++)
{
list += ",?";
}
return list;
}
//Prompts the user for a yes/no response
public static boolean confirm(String prompt)
{
Scanner keyboard = new Scanner(System.in);
String response;
while(true)
{
System.out.println(prompt+" (enter y for yes or n for no)");
response = keyboard.nextLine().toLowerCase();
if(response.equals("y"))
{
return true;
}
else if(response.equals("n"))
{
return false;
}
else
{
System.out.println("That is not a valid response. Please try again");
}
}
}
}
