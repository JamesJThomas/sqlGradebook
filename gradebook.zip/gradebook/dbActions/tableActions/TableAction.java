package dbActions.tableActions;
import dbActions.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.*;
public abstract class TableAction implements DbAction
{
// the database connection that will be used to access the database
protected Connection connection;
//The entity that this action is operating on
protected String entity;
//List of parameters for insertion
Parameter[] insert;
private String primaryKey;
public TableAction(Connection c)
{
connection = c;
entity = "";
insert = new Parameter[] {};
}
public String getPrimaryKey()
{
return entity+"_id";
}
public void perform() throws ProgramDoneException
{
Scanner keyboard = new Scanner(System.in);
int choice = 0;
boolean valid = false;
while(!valid)
{
System.out.println("please select from the folloing options:\n1: insert\n2: delete\n3: update\n4: list");
try
{
choice = keyboard.nextInt();
}
catch(Exception e)
{
System.out.println("That was not a valid choice. Please try again");
keyboard.nextLine();
continue;
}
switch(choice)
{
case 1:
insert();
valid = true;
break;
case 2:
delete();
valid = true;
break;
case 3:
update();
valid = true;
break;
case 4:
list();
valid = true;
break;
default:
System.out.println("Choice should be in the range 1 through 4");
break;
}
}
}
public void insert()
{
int i;
//Prepare the SQL procedure call
CallableStatement cs = null;
try
{
cs = connection.prepareCall(String.format("{call insert_%s(%s)}",entity,Utils.getParameterList(insert.length)));
}
catch(SQLException s)
{
System.out.println(s.getMessage());
return;
}
for(i = 0; i < insert.length; i++)
{
//Each parameter is a prompt
String prompt = insert[i].getDescription();
//set the appropriate parameter type
switch(insert[i].getType())
{
case INT:
Utils.setInt(cs,i+1,Utils.readInt(prompt));
break;
case DOUBLE:
Utils.setDouble(cs,i+1,Utils.readDouble(prompt));
break;
default:
Utils.setString(cs,i+1,Utils.readString(prompt));
break;
}
}
//Try to execute the query
try
{
cs.executeQuery();
}
catch(SQLException s)
{
System.out.println(s.getMessage());
return;
}
}
public void delete()
{
int id = Utils.readInt("enter the id number of the "+entity+" you wish to delete");
boolean delete = Utils.confirm("Are you sure you wish to delete the "+entity+" with id "+id+"? If you choose to delete it, then this "+entity+" and all associated data will be deleted");
if(delete)
{
try
{
CallableStatement cs = connection.prepareCall("{call delete_"+entity+"(?)}");
cs.setInt(1,id);
cs.executeQuery();
}
catch(SQLException s)
{
System.out.println(s.getMessage());
}
}
else
{
System.out.println("deletion canceled");
}
}
public void update()
{
int id = Utils.readInt("enter the id of the "+entity+" you wish to update");
int attributeNumber = selectAttribute();
if(attributeNumber < 1 || attributeNumber > insert.length)
{
System.out.println("Attribute number should be between 1 and "+insert.length);
}
else
{
String attributeName = insert[attributeNumber-1].getAffectedColumn();
try
{
PreparedStatement ps = connection.prepareStatement(String.format("update %s set %s = ? where %s = ?",entity,attributeName,getPrimaryKey()));
ps.setInt(2,id);
switch(insert[attributeNumber-1].getType())
{
case INT:
ps.setInt(1,Utils.readInt("Enter the new value for "+attributeName));
break;
case DOUBLE:
ps.setDouble(1,Utils.readDouble("Enter the new value for "+attributeName));
break;
default:
ps.setString(1,Utils.readString("Enter the new value for "+attributeName));
break;
}
ps.executeUpdate();
}
catch(SQLException s)
{
System.out.println(s.getMessage());
}
}
}
public void list()
{
try
{
CallableStatement cs = connection.prepareCall("{call list_"+entity+"()}");
System.out.print(new ResultSetViewer(cs.executeQuery()));
}
catch(SQLException s)
{
System.out.println(s.getMessage());
}
}
public int selectAttribute()
{
String menu = getAttributeMenu(insert);
int attributeNumber = Utils.readInt(menu);
return attributeNumber;
}
public String getAttributeMenu(Parameter[] attributes)
{
String menu = "please select from the following options:";
int i;
for(i = 0; i < attributes.length; i++)
{
menu += ""+(i+1)+": "+attributes[i].getAffectedColumn()+"\n";
}
return menu;
}
}
