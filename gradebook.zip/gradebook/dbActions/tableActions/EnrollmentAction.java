package dbActions.tableActions;
import java.sql.*;
public class EnrollmentAction extends TableAction
{
public EnrollmentAction(Connection c)
{
super(c);
entity = "enrollment";
insert = new Parameter[2];
insert[0] = new Parameter("enter the id number of the student to which this enrollment applies",Type.INT,"student_id");
insert[1] = new Parameter("Enter the id number of the course in which the student is enrolling",Type.INT,"course_id");
}
}
