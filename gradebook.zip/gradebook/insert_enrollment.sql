create procedure insert_enrollment(stu_id int, cou_id int)
begin
if not exists(select * from student where student_id = stu_id) then
call display_error(concat("student ",stu_id," doesn't exist"));
elseif not exists(select * from course where course_id = cou_id) then
call display_error(concat("course ",cou_id," doesn't exist"));
elseif exists(select * from enrollment where student_id = stu_id and course_id = cou_id) then
call display_error(concat("student ",stu_id," is already enrolled in course ",cou_id));
else
insert into enrollment(student_id,course_id) values(stu_id,cou_id);
end if;
end$
