create procedure delete_category(cat_id int)
begin
if not exists(select * from category where category_id = cat_id) then
call display_error(concat("category ",cat_id," doesn't exist. For a full listing of categories, select category->list"));
else
delete from category where category_id = cat_id;
end if;
end$
