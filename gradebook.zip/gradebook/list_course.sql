create procedure list_course()
begin
select * from course;
end$
