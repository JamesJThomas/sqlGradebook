create procedure list_category()
begin
select * from category;
end$
