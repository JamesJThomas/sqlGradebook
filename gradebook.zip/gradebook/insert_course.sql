create procedure insert_course(subject varchar(3), level int, section int, description varchar(255), term int, year int)
begin
if level < 1 or level > 9999 then 
call display_error(concat(level," is not a valid course level. Course levels should be between 1 and 9999"));
elseif section < 1 or section > 99 then 
call display_error(concat(section," is not a valid section. Section numbers should be between 1 and 99"));
elseif term < 1 or term > 3 then
call display_error("term must be 1 for fall, 2 for spring, or 3 for summer");
else
insert into course(course_subject, course_level, course_section, course_description, course_term, course_year) values(subject, level, section, description, term,year);
end if;
end$
