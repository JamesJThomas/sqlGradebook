create procedure list_assignment()
begin
select * from assignment;
end$
