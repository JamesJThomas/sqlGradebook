create procedure delete_score(sco_id int)
begin
if not exists(select * from score where score_id = sco_id) then
call display_error(concat("score ",sco_id," does not exist. For a full listing of scores, select score->list"));
else
delete from score where score_id = sco_id;
end if;
end$
