create procedure delete_student(stu_id int)
begin
if not exists(select * from student where student_id = stu_id) then
call display_error(concat("student ",stu_id," doesn't exist. For a full listing of students, select student->list"));
else
delete from student where student_id = stu_id;
end if;
end$
