create procedure insert_category(description varchar(255),cou_id int, weight double)
begin
if not exists(select * from course where course_id = cou_id) then
call display_error(concat("course ",cou_id," doesn't exist"));
elseif weight <= 0 then
call display_error("weight must be a positive real number");
else
insert into category(category_description, course_id, category_weight) values(description,cou_id,weight);
end if;
end$
