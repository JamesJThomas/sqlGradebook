/*
Function to calculate a student's grade in a given course.
Parameters:
stu_id: the id of the student for whom the grade is to be calculated.
cou_id: the course for which the grade is to be calculated
current: selects whether a current or final grade is to be calculated. For final grades, current = 0. For current grades, current is nonzero
returns: the numeric grade for the student in the specified course as a double. The numeric grade will usually be between 0 and 1, but may exceed 1 if the professor awards extra credit.
*/
create function calculate_grade(stu_id int, cou_id int, current int) returns double
begin
declare enr_id int;
declare grade double;
/*Find the enrollment corresponding to this course and student*/
if not exists(select * from enrollment where student_id = stu_id and course_id = cou_id) then
call display_error(concat("student ",stu_id," isn't enrolled in course ",cou_id));
else
set enr_id = (select enrollment_id from enrollment where student_id = stu_id and course_id = cou_id);
end if;
/*Now, create a temporary table that will hold information about the assignments completed by this student. This information will be helpful later*/
/*Fixes a bug where this function could only be run once.*/
drop temporary table if exists completed_assignments;
create temporary table completed_assignments(assg_id int, score_earned int, points_possible int);
/*Retrieve the student's scores and insert them into the completed_assignments table*/
insert into completed_assignments(assg_id, completed_assignments.score_earned, points_possible) select assignment.assignment_id, score.score_points_earned, assignment_points_possible from score join assignment on score.assignment_id = assignment.assignment_id;
/*If we are calculating a final grade, fill in missing assignments with 0 scores.*/
if current = 0 then
/*get the list of all assignments in the course*/
drop temporary table if exists course_assignments;
create temporary table course_assignments(assg_id_course int, points_possible int);
insert into course_assignments(assg_id_course,points_possible) select assignment_id, assignment_points_possible from assignment join category on assignment.category_id = category.category_id where course_id = cou_id;
/*The missing assignments are those that are part of the course but were not completed by the student*/
drop temporary table if exists missing_assignments;
create temporary table missing_assignments(assg_id_missing int, points_possible int);
insert into missing_assignments(assg_id_missing, points_possible) select * from course_assignments where assg_id_course not in (select assg_id from completed_assignments);
/*Fill the completed assignments table with 0 scores for the missing assignments*/
insert into completed_assignments(assg_id, completed_assignments.score_earned, points_possible) select assg_id_missing, 0, points_possible from missing_assignments;
/*Drop the missing assignments and course assignments tables since they are no longer necessary*/
drop temporary table missing_assignments;
drop temporary table course_assignments;
end if;
/*Create a table that will hold the aggregate scores for each category*/
drop temporary table if exists category_summary;
create temporary table category_summary(category_id int, points_earned int, points_possible int);
insert into category_summary(category_id,points_earned,points_possible) select category_id, sum(score_earned), sum(points_possible) from completed_assignments join assignment on assg_id = assignment_id group by category_id;
/*The final grade is then equal to the weighted average of the percentage of points earned in all categories*/
set grade = (select sum(points_earned*1.0/points_possible*category_weight)/sum(category_weight) from category_summary join category on category_summary.category_id = category.category_id);
/*Drop the temporary tables to avoid clogging up the database*/
drop temporary table category_summary;
drop temporary table completed_assignments;
return grade;
end$
