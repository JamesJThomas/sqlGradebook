create procedure list_enrollment()
begin
select * from enrollment;
end$
