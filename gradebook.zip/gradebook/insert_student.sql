create procedure insert_student(stu_id int, fname varchar(255), mi varchar(1), lname varchar(255), suffix varchar(2))
begin
if stu_id < 1 then
call display_error(concat(stu_id," is not a valid student id. Student id numbers should be a positive integer"));
elseif exists(select * from student where student_id = stu_id) then
call display_error(concat("student with id ",stu_id," already exists"));
else
insert into student(student_id, student_first_name, student_last_name) values(stu_id,fname,lname);
if suffix <> "" then
update student set student_suffix = suffix where student_id = stu_id;
end if;
if mi <> "" then
update student set student_middle_initial = mi where student_id = stu_id;
end if;
end if;
end$
