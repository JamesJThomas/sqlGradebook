create procedure delete_assignment(asg_id int)
begin
if not exists(select * from assignment where assignment_id = asg_id) then
call display_error(concat("assignment ",asg_id," doesn't exist. For a full listing of assignments, select assignment->list"));
else
delete from assignment where assignment_id = asg_id;
end if;
end$
