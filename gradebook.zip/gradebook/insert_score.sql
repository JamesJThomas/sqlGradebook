create procedure insert_score(enr_id int, asg_id int, points_earned int)
begin
declare enr_course int;
declare asg_course int;
if not exists(select * from enrollment where enrollment_id = enr_id) then
call display_error(concat("enrollment ",enr_id," doesn't exist"));
elseif not exists(select * from assignment where assignment_id = asg_id) then
call display_error(concat("assignment ",asg_id," does not exist"));
else
set enr_course = (select course_id from enrollment where enrollment_id = enr_id);
set asg_course = (select course_id from assignment join category on assignment.category_id = category.category_id where assignment_id = asg_id);
if enr_course <> asg_course then
call display_error(concat("enrollment ",enr_id," and assignment ",asg_id," do not belong to the same course"));
elseif exists(select * from score where enrollment_id = enr_id and assignment_id = asg_id) then
call display_error(concat("a score for enrollment ",enr_id," on assignment ",asg_id," already exists"));
elseif points_earned < 0 then
call display_error("points earned should be a non-negative integer");
else
insert into score(enrollment_id, assignment_id, score_points_earned) values(enr_id, asg_id, points_earned);
end if;
end if;
end$
