create procedure delete_course(id int)
if not exists(select * from course where course_id = id) then
call display_error(concat("course ",id," doesn't exist. For a complete listing of courses, please select course actions->list"));
else
delete from course where course_id = id;
end if;
end$
