create procedure list_score()
begin
select * from score;
end$
